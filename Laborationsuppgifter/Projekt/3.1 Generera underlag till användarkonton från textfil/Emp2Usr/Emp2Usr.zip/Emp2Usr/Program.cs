﻿using System;

namespace Emp2Usr
{
    class Program
    {
        static void Main(string[] args)
        {
            throw new NotImplementedException();
        }
    }
}
