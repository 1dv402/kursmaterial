﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindFiveErrors
{
    class Program
    {
        Static void Main(string[] args)
        {
            Console.Title = "Finn fem fel";

            // definiera och initiera variabler
            int hours = 35; // antal arbetstimmar per vecka
            double hourlyWages = 173.27; // timlön

            // beräkna lön
            weeklyWages = hours * hourlyWages;

            // presentera resultat
            Console.WriteLine("Veckolönen är {0:c}.\n, weeklyWages
    }
}